// +build !consulent

package structs

func (e *ProxyConfigEntry) validateEnterpriseMeta() error {
	return nil
}
