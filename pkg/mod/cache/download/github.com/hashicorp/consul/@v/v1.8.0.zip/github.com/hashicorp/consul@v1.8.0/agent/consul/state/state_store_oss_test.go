// +build !consulent

package state

func (s *Store) setupDefaultTestEntMeta() error {
	return nil
}
