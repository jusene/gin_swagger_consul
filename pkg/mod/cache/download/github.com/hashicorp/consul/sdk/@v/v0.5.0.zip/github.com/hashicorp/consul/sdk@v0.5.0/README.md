## Internal SDK

Please note that this folder, while public, is not meant for new consumers of
these libraries; this should currently be considered an internal, not external,
SDK. It is public due to existing needs from other HashiCorp software. The tags
in this folder will stay at the 0.x.y level; accordingly users should expect
that things can move around, disappear, or change API at any time.
