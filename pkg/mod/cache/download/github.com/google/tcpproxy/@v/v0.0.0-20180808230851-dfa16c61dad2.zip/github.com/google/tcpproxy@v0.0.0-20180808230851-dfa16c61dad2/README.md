# tcpproxy

For library usage, see https://godoc.org/github.com/google/tcpproxy/

For CLI usage, see https://github.com/google/tcpproxy/blob/master/cmd/tlsrouter/README.md
