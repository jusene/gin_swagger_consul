# googleapis

These are selected gogoslick-compiled from: https://github.com/googleapis/googleapis.

The SHA of the source protos is pegged to: `c8c975543a134177cc41b64cbbf10b88fe66aa1d`.

If you wish to use a different version, update the `Makefile` at root.